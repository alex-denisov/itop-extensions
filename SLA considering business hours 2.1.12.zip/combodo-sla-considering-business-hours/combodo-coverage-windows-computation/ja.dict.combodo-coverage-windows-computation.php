<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('JA JP', 'Japanese', '日本語', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Coverage window~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Coverage window name~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '~~',
));


