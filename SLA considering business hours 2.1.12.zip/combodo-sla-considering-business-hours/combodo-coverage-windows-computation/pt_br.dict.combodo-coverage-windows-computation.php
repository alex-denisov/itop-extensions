<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('PT BR', 'Brazilian', 'Brazilian', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Janela de cobertura',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Nome janela de cobertura',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '',
));


