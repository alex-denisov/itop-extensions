<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('ZH CN', 'Chinese', '简体中文', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Coverage window~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Coverage window name~~',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '~~',
));


