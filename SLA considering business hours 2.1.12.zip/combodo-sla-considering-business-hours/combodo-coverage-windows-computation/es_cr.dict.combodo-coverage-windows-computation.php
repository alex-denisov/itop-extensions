<?php

//
// Class: lnkCustomerContractToService
//
Dict::Add('ES CR', 'Spanish', 'Español, Castellaño', array(
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id' => 'Ventana de Cobertura',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_id+' => '',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name' => 'Nombre de Ventana de Cobertura',
	'Class:lnkCustomerContractToService/Attribute:coveragewindow_name+' => '',
));


